package homeWork3.fruitBox;

public abstract class Fruit {
}
